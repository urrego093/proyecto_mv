# -*- coding: utf-8 -*-
#Define constants
STR_DAL ="postgres://gato:gato123@localhost/base"

#This is for operating system use in the virtual machine
OPERA_SYSTEM = ['Fedora','CentOs','Ubuntu','Kali','Windows', T('Other')]
#Possible Memory RAM for VM
RAM_MEMORY = ['512MB','1024MB','2048MB','3072MB','4096MB','5120MB','6144MB','7168MB','8192MB','9216MB','10240MB', T('Other MB')]
#Processor for VM
PROCESSOR = ['1','2','3','4','5','6','7','8','9','10', T('Other')]
#This is semestre for to assing in the group or in the VM for student
SEMESTER = ['2016-I','2016-III','2017-I','2017-III','2018-I','2018-III','2019-I','2019-III','2020-I','2020-III','2021-I','2021-III','2022-I','2022-III','2023-I','2023-III','2024-I','2024-III','2025-I','2025-III']
#This ports using for connection

P_HOST = ['5901','5902','5903','5904','5905','5906','5907','5908','5909','5910','5911','5912','5913','5914','5915','5916']
#user for OS depending to port
HOSTNAME = ['root','estudiante1','estudiante2','estudiante3','estudiante4','estudiante5','estudiante6','estudiante7','estudiante8','estudiante9','estudiante10','estudiante11','estudiante12','estudiante13','estudiante14','estudiante15']
